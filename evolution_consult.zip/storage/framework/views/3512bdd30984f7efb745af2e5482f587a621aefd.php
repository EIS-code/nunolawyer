<?php $__env->startSection('sub_content'); ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="breadcrumb-item"><?php echo e(__('Permissions')); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(__('Permission Details')); ?></span>
                </div>
            </div>
        </div>
    </div>
	
    <div class="content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card bg-white">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-title pull-right">
                            <div class="heading">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions_edit')): ?>
                                    <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>" class="btn btn-primary btn-round"><i class="fa fa-edit"></i> <span class="d-md-inline d-none"><?php echo e(__('Edit')); ?></span></a>
                                <?php endif; ?>

                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions_delete')): ?>
                                    <form action="<?php echo e(route('permissions.destroy', $permission->id)); ?>" method="POST" class="d-inline">
                                        <?php echo method_field('DELETE'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button type="button" class="btn btn-danger btn-round deleteBtn" data-confirm-message="<?php echo e(__("Are you sure you want to delete this permission?")); ?>"><i class="fa fa-trash"></i> <span class="d-md-inline d-none"><?php echo e(__('Delete')); ?></span></button>
                                    </form>
                                <?php endif; ?>

                                <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-secondary btn-round"><i class="metismenu-icon pe-7s-back"></i> <span class="d-md-inline d-none"><?php echo e(__('Back To List')); ?></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2"><?php echo e(__('Name')); ?></div>
                    <div class="col-md-8">
                        <?php echo e($permission->name); ?>

                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2"><?php echo e(__('Display Name')); ?></div>
                    <div class="col-md-8">
                        <?php echo e($permission->display_name); ?>

                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2"><?php echo e(__('Group Name')); ?></div>
                    <div class="col-md-8">
                        <?php echo e($permission->group_name); ?>

                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2"><?php echo e(__('Group Slug')); ?></div>
                    <div class="col-md-8">
                        <?php echo e($permission->group_slug); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/permissions/show.blade.php ENDPATH**/ ?>