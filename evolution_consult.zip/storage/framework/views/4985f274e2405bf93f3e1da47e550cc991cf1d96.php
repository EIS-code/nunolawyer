<?php $__env->startSection('content'); ?>
        <div class="app-sidebar sidebar-shadow">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>
            <div class="scrollbar-sidebar">
                <div class="app-sidebar__inner">
                    <ul class="vertical-nav-menu">
                        <li class="app-sidebar__heading"></li>
                        <li>
                            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e((request()->is('/') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-refresh-2"></i>
                                <?php echo e(__('Dashboards')); ?>

                            </a>
                        </li>
                        <!--li class="app-sidebar__heading">Clients</li-->
                        <li>
                            <a href="<?php echo e(route('clients.index')); ?>" class="<?php echo e((request()->is('clients*') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-users"></i>
                                <?php echo e(__('Add New client')); ?>

                            </a>
                        </li>
                        <!--li>
                            <a href="#">
                                <i class="metismenu-icon pe-7s-albums"></i>
                                <?php echo e(__('View all clients')); ?>

                            </a>
                        </li>
                        <li  >
                            <a href="tables-regular.html">
                                <i class="metismenu-icon pe-7s-search"></i>
                                <?php echo e(__('Search clients')); ?>

                            </a>
                        </li-->
                        <!--li class="app-sidebar__heading"><?php echo e(('Editors')); ?></li-->
                        <li>
                            <a href="<?php echo e(route('editors.index')); ?>" class="<?php echo e((request()->is('editors*') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-display2"></i>
                                <?php echo e(__('View all editors')); ?>

                            </a>
                        </li>
                        <!--li class="app-sidebar__heading"><?php echo e(__('Article / Purpose')); ?></li-->
                        <li>
                            <a class="<?php echo e((request()->is('') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-notebook"></i>
                                <?php echo e(__('Article / Purpose')); ?>

                            </a>
                        </li>
                        <!--li class="app-sidebar__heading"><?php echo e(__('POA & agreement')); ?></li-->
                        <li>
                            <a class="<?php echo e((request()->is('') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-note"></i>
                                <?php echo e(__('POA & agreement')); ?>

                            </a>
                        </li>
                        <!--li class="app-sidebar__heading"><?php echo e(__('Translate model or documents')); ?></li-->
                        <li>
                            <a class="<?php echo e((request()->is('') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-file"></i>
                                <?php echo e(__('Translate model or documents')); ?>

                            </a>
                        </li>
                        <!--li class="app-sidebar__heading"><?php echo e(__('Our fee / policy document')); ?></li-->
                        <li>
                            <a class="<?php echo e((request()->is('') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-file"></i>
                                <?php echo e(__('Our fee / policy document')); ?>

                            </a>
                        </li>
                        <!--li class="app-sidebar__heading"><?php echo e(__('Account')); ?></li-->
                        <li>
                            <a class="<?php echo e((request()->is('') ? 'mm-active' : '')); ?>">
                                <i class="metismenu-icon pe-7s-pen"></i>
                                <?php echo e(__('Account')); ?>

                            </a>
                        </li>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_access')): ?>
                            <li>
                                <a href="<?php echo e(route('roles.index')); ?>" class="<?php echo e((request()->is('roles*') ? 'mm-active' : '')); ?>">
                                    <i class="metismenu-icon pe-7s-lock"></i> 
                                    <?php echo e(__('Roles')); ?>

                                </a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permissions_access')): ?>  
                            <li>
                                <a href="<?php echo e(route('permissions.index')); ?>" class="<?php echo e((request()->is('permissions*') ? 'mm-active' : '')); ?>">
                                    <i class="metismenu-icon pe-7s-settings"></i> 
                                    <?php echo e(__('Permissions')); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
        <div class="app-main__outer">
            <div class="app-main__inner">
                <?php echo $__env->yieldContent('sub_content'); ?>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/layout.blade.php ENDPATH**/ ?>