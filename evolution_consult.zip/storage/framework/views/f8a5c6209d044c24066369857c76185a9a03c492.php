<?php $__env->startSection('sub_content'); ?>

    <?php
        $isEditors = $client::$isEditors;
    ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('clients.index')); ?>" class="breadcrumb-item"><?php echo e(($isEditors ? __('Editors') : __('Clients'))); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(($isEditors ? __('Edit Editor') : __('Edit Client'))); ?></span>
                    <span class="breadcrumb-item active"><?php echo e($client->first_name . ' ' . $client->last_name); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="card bg-white">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route(($isEditors ? 'editors.update' : 'clients.update'), $client->id)); ?>" enctype='multipart/form-data'>
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Registration Date')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="registration_date" type="date" class="form-control<?php echo e($errors->has('registration_date') ? ' is-invalid' : ''); ?>" name="registration_date" value="<?php echo e(date('Y-m-d', strtotime($client->registration_date))); ?>" required autofocus>

                            <?php if($errors->has('registration_date')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('registration_date')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('First Name')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="first_name" type="text" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e($client->first_name); ?>" required autofocus>

                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Last Name')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="last_name" type="text" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" name="last_name" value="<?php echo e($client->last_name); ?>">

                            <?php if($errors->has('last_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('E-Mail')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e($client->email); ?>" required>

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Secondary E-Mail')); ?></div>
                        <div class="col-md-8">
                            <input id="secondary_email" type="email" class="form-control<?php echo e($errors->has('secondary_email') ? ' is-invalid' : ''); ?>" name="secondary_email" value="<?php echo e($client->secondary_email); ?>">

                            <?php if($errors->has('secondary_email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('secondary_email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!--div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Password')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Confirm Password')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>
                    </div-->
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Date of birth')); ?></div>
                        <div class="col-md-8">
                            <input id="dob" type="date" class="form-control<?php echo e($errors->has('dob') ? ' is-invalid' : ''); ?>" name="dob" value="<?php echo e($client->dob); ?>">

                            <?php if($errors->has('dob')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('dob')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Contact')); ?></div>
                        <div class="col-md-3">
                            <input id="contact" type="number" class="form-control<?php echo e($errors->has('contact') ? ' is-invalid' : ''); ?>" name="contact" value="<?php echo e($client->contact); ?>">

                            <?php if($errors->has('contact')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('contact')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Passport Number')); ?></div>
                        <div class="col-md-3">
                            <input id="passport_number" type="text" class="form-control<?php echo e($errors->has('passport_number') ? ' is-invalid' : ''); ?>" name="passport_number" value="<?php echo e($client->passport_number); ?>">

                            <?php if($errors->has('passport_number')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('passport_number')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Process Address')); ?></div>
                        <div class="col-md-8">
                            <input id="process_address" type="text" class="form-control<?php echo e($errors->has('process_address') ? ' is-invalid' : ''); ?>" name="process_address" value="<?php echo e($client->process_address); ?>">

                            <?php if($errors->has('process_address')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('process_address')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <?php $purposeArticleIds = $client->clientPurposeArticles->pluck('purpose_article_id')->toArray(); ?>

                        <div class="col-md-2"><?php echo e(__('Purpose and Article')); ?></div>
                        <div class="col-md-8">
                            <select class="form-control<?php echo e($errors->has('nationality') ? ' is-invalid' : ''); ?>" name="purpose_articles[]" multiple="true">
                                <option value="" <?php echo e((empty($purposeArticleIds) ? 'selected="true"' : '')); ?>><?php echo e(__('Select')); ?></option>

                                <?php $__currentLoopData = $purposeArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purposeArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($purposeArticle->id); ?>" <?php echo e((!empty($purposeArticleIds) && in_array($purposeArticle->id, $purposeArticleIds) ? 'selected="true"' : '')); ?>><?php echo e($purposeArticle->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('purpose_articles')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('purpose_articles')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row" id="row-pa">
                        <?php
                            $clientConditions = $client->clientConditions->toArray();

                            if (empty($clientConditions)) {
                                $clientConditions[] = [
                                    'id'        => '',
                                    'date'      => '',
                                    'condition' => ''
                                ];
                            }
                        ?>

                        <div class="col-md-2"><?php echo e(__('Client Condition / Work To Do')); ?></div>

                        <div class="col-md-10">
                            <?php $__currentLoopData = $clientConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientCondition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="<?php echo e(($index == 0 ? 'main-pa' : '')); ?>">
                                    <div class="col-md-12">
                                        <table class="table table-respopnsive table-bordered">
                                            <thead>
                                                <th width="1%">#</th>
                                                <th width="20%"><?php echo e(__('Date')); ?></th>
                                                <th width="79%"><?php echo e(__('Client Condition')); ?></th>
                                                <th></th>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td ><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <input type="date" class="form-control<?php echo e($errors->has('condition_dates.' . $index) ? ' is-invalid' : ''); ?>" name="condition_dates[]" value="<?php echo e(old('condition_dates.' . $index, (!empty($clientCondition['date']) ? date('Y-m-d', strtotime($clientCondition['date'])) : ''))); ?>">

                                                        <?php if($errors->has('condition_dates.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('condition_dates.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <textarea class="form-control<?php echo e($errors->has('conditions.' . $index) ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="conditions[]"><?php echo e(old('conditions.' . $index, $clientCondition['condition'])); ?></textarea>

                                                        <?php if($errors->has('conditions.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('conditions.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <i class="<?php echo e(($index == 0 ? 'fa fa-plus' : 'fa fa-trash')); ?>" id="<?php echo e(($index == 0 ? 'plus-pa' : 'minus-pa')); ?>" style="cursor: pointer;"></i>
                                                    </td>
                                                    <input type="hidden" name="id_client_conditions[]" value="<?php echo e($clientCondition['id']); ?>" />
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="cloned-pa"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-cf">
                        <?php
                            $clientFees = $client->clientFees->toArray();

                            if (empty($clientFees)) {
                                $clientFees[] = [
                                    'id'                      => '',
                                    'date'                    => '',
                                    'proposed_lawyer_fee'     => '',
                                    'received_lawyer_fee'     => '',
                                    'missing_lawyer_fee'      => '',
                                    'proposed_government_fee' => '',
                                    'received_government_fee' => '',
                                    'missing_government_fee'  => ''
                                ];
                            }
                        ?>

                        <div class="col-md-2"><?php echo e(__('Client Fee')); ?></div>

                        <div class="col-md-10">
                            <?php $__currentLoopData = $clientFees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientFee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="<?php echo e(($index == 0 ? 'main-cf' : '')); ?>">
                                    <div class="col-md-12 table-respopnsive text-nowrap">
                                        <table class="table table-bordered" width="100%;">
                                            <thead>
                                                <tr>
                                                    <th style="width: 1%">#</th>
                                                    <th style="width: 10%"><?php echo e(__('Date')); ?></th>
                                                    <th style="width: 15%"><?php echo e(__('Total Proposed - Lawyer Fee')); ?></th>
                                                    <th style="width: 15%"><?php echo e(__('Received -Lawyer Fee')); ?></th>
                                                    <th style="width: 15%"><?php echo e(__('Missing- Lawyer Fee')); ?></th>
                                                    <th style="width: 1%"></th>
                                                </tr>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td rowspan="4"><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <input type="date" class="form-control<?php echo e($errors->has('fee_dates.' . $index) ? ' is-invalid' : ''); ?>" name="fee_dates[]" value="<?php echo e(old('fee_dates.' . $index, (!empty($clientFee['date']) ? date('Y-m-d', strtotime($clientFee['date'])) : ''))); ?>">

                                                        <?php if($errors->has('fee_dates.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('fee_dates.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <input type="text" class="form-control<?php echo e($errors->has('total_proposed_lawyer_fee.' . $index) ? ' is-invalid' : ''); ?>" name="total_proposed_lawyer_fee[]" value="<?php echo e(old('total_proposed_lawyer_fee.' . $index, $clientFee['proposed_lawyer_fee'])); ?>">

                                                        <?php if($errors->has('total_proposed_lawyer_fee.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('total_proposed_lawyer_fee.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control<?php echo e($errors->has('received_lawyer_fee.' . $index) ? ' is-invalid' : ''); ?>" name="received_lawyer_fee[]" value="<?php echo e(old('received_lawyer_fee.' . $index, $clientFee['received_lawyer_fee'])); ?>">

                                                        <?php if($errors->has('received_lawyer_fee.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('received_lawyer_fee.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control<?php echo e($errors->has('missing_lawyer_fee.' . $index) ? ' is-invalid' : ''); ?>" name="missing_lawyer_fee[]" value="<?php echo e(old('missing_lawyer_fee.' . $index, $clientFee['missing_lawyer_fee'])); ?>">

                                                        <?php if($errors->has('missing_lawyer_fee.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('missing_lawyer_fee.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td  rowspan="4">
                                                        <i class="<?php echo e(($index == 0 ? 'fa fa-plus' : 'fa fa-trash')); ?>" id="<?php echo e(($index == 0 ? 'plus-cf' : 'minus-cf')); ?>" style="cursor: pointer;"></i>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th style="width: 15%"><?php echo e(__('Total Proposed-Gov Fee')); ?></th>
                                                    <th style="width: 15%"><?php echo e(__('Received-Gov Fee')); ?></th>
                                                    <th style="width: 15%"><?php echo e(__('Missing-Gov Fee')); ?></th>
                                                    <th rowspan="2"></th>
                                                <tr>
                                                    <td>
                                                        <input type="text" class="form-control<?php echo e($errors->has('total_proposed_government_fee.' . $index) ? ' is-invalid' : ''); ?>" name="total_proposed_government_fee[]" value="<?php echo e(old('total_proposed_government_fee.' . $index, $clientFee['proposed_government_fee'])); ?>">

                                                        <?php if($errors->has('total_proposed_government_fee.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('total_proposed_government_fee.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control<?php echo e($errors->has('received_government_fee.' . $index) ? ' is-invalid' : ''); ?>" name="received_government_fee[]" value="<?php echo e(old('received_government_fee.' . $index, $clientFee['received_government_fee'])); ?>">

                                                        <?php if($errors->has('received_government_fee.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('received_government_fee.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <input type="number" class="form-control<?php echo e($errors->has('missing_government_fee.' . $index) ? ' is-invalid' : ''); ?>" name="missing_government_fee[]" value="<?php echo e(old('missing_government_fee.' . $index, $clientFee['missing_government_fee'])); ?>">

                                                        <?php if($errors->has('missing_government_fee.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('missing_government_fee.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <input type="hidden" name="id_client_fees[]" value="<?php echo e($clientFee['id']); ?>" />
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="cloned-cf"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-pr">
                        <?php
                            $clientEmailProgressReports = $client->clientEmailProgressReports->toArray();

                            if (empty($clientEmailProgressReports)) {
                                $clientEmailProgressReports[] = [
                                    'id'              => '',
                                    'date'            => '',
                                    'progress_report' => '',
                                    'file'            => ''
                                ];
                            }
                        ?>

                        <div class="col-md-2"><?php echo e(__('Progress Report To The Client (By Email)')); ?></div>

                        <div class="col-md-10">
                            <?php $__currentLoopData = $clientEmailProgressReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientEmailProgressReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="<?php echo e(($index == 0 ? 'main-pr' : '')); ?>">
                                    <div class="table-respopnsive col-md-12">
                                        <table class="table table-bordered">
                                            <thead>
                                                <th width="1%">#</th>
                                                <th width="20%"><?php echo e(__('Date')); ?></th>
                                                <th width="69%"><?php echo e(__('Progress Report')); ?></th>
                                                <th width="10%"><?php echo e(__('File')); ?></th>
                                                <th></th>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td ><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <input type="date" class="form-control<?php echo e($errors->has('progress_report_dates.' . $index) ? ' is-invalid' : ''); ?>" name="progress_report_dates[]" value="<?php echo e(old('progress_report_dates.' . $index, (!empty($clientEmailProgressReport['date']) ? date('Y-m-d', strtotime($clientEmailProgressReport['date'])) : ''))); ?>">

                                                        <?php if($errors->has('progress_report_dates.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('progress_report_dates.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <textarea class="form-control<?php echo e($errors->has('progress_reports.' . $index) ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="progress_reports[]"><?php echo e(old('progress_reports.' . $index, $clientEmailProgressReport['progress_report'])); ?></textarea>

                                                        <?php if($errors->has('progress_reports.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('progress_reports.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if(!empty($clientEmailProgressReport['file'])): ?>
                                                            <a href="<?php echo e($clientEmailProgressReport['file']); ?>" target="_blank"><?php echo e(__('View')); ?></a><br />
                                                        <?php endif; ?>
                                                        <input type="file" class="<?php echo e($errors->has('progress_report_files.' . $index) ? ' is-invalid' : ''); ?>" name="progress_report_files[]" />

                                                        <?php if($errors->has('progress_report_files.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('progress_report_files.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <i class="<?php echo e(($index == 0 ? 'fa fa-plus' : 'fa fa-trash')); ?>" id="<?php echo e(($index == 0 ? 'plus-pr' : 'minus-pr')); ?>" style="cursor: pointer;"></i>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $clientEmailProgressReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientEmailProgressReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="id_client_email_progress_reports[]" value="<?php echo e($clientEmailProgressReport['id']); ?>" />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="cloned-pr"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-ci">
                        <?php
                            $clientPrivateInformations = $client->clientPrivateInformations->toArray();

                            if (empty($clientPrivateInformations)) {
                                $clientPrivateInformations[] = [
                                    'id'                  => '',
                                    'date'                => '',
                                    'private_information' => ''
                                ];
                            }
                        ?>

                        <div class="col-md-2"><?php echo e(__('Client Private Information')); ?></div>

                        <div class="col-md-10">
                            <?php $__currentLoopData = $clientPrivateInformations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientPrivateInformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="<?php echo e(($index == 0 ? 'main-ci' : '')); ?>">
                                    <div class="col-md-12">
                                        <table class="table table-respopnsive table-bordered">
                                            <thead>
                                                <th width="1%">#</th>
                                                <th width="20%"><?php echo e(__('Date')); ?></th>
                                                <th width="79%"><?php echo e(__('Client Private Information')); ?></th>
                                                <th></th>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td ><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <input type="date" class="form-control<?php echo e($errors->has('client_private_dates.' . $index) ? ' is-invalid' : ''); ?>" name="client_private_dates[]" value="<?php echo e(old('client_private_dates.' . $index, (!empty($clientPrivateInformation['date']) ? date('Y-m-d', strtotime($clientPrivateInformation['date'])) : ''))); ?>">

                                                        <?php if($errors->has('client_private_dates.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('client_private_dates.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <textarea class="form-control<?php echo e($errors->has('client_private_informations.' . $index) ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="client_private_informations[]"><?php echo e(old('client_private_informations.' . $index, $clientPrivateInformation['private_information'])); ?></textarea>

                                                        <?php if($errors->has('client_private_informations.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('client_private_informations.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <i class="<?php echo e(($index == 0 ? 'fa fa-plus' : 'fa fa-trash')); ?>" id="<?php echo e(($index == 0 ? 'plus-ci' : 'minus-ci')); ?>" style="cursor: pointer;"></i>
                                                    </td>
                                                    <input type="hidden" name="id_client_private_informations[]" value="<?php echo e($clientPrivateInformation['id']); ?>" />
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="cloned-ci"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-cd">
                        <?php
                            $clientDocuments = $client->clientDocuments->toArray();

                            if (empty($clientDocuments)) {
                                $clientDocuments[] = [
                                    'id'   => '',
                                    'file' => ''
                                ];
                            }
                        ?>

                        <div class="col-md-2"><?php echo e(__('Client Documents')); ?></div>

                        <div class="col-md-10">
                            <?php $__currentLoopData = $clientDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="<?php echo e(($index == 0 ? 'main-cd' : '')); ?>">
                                    <div class="col-md-12">
                                        <table class="table table-respopnsive table-bordered">
                                            <thead>
                                                <th width="1%">#</th>
                                                <th width="99%"><?php echo e(__('File')); ?></th>
                                                <th></th>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td ><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <?php if(!empty($clientDocument['file'])): ?>
                                                            <a href="<?php echo e($clientDocument['file']); ?>" target="_blank"><?php echo e(__('View')); ?></a><br />
                                                        <?php endif; ?>
                                                        <input type="file" class="form-control<?php echo e($errors->has('client_documents.' . $index) ? ' is-invalid' : ''); ?>" name="client_documents[]" value="<?php echo e(old('client_documents.' . $index)); ?>">

                                                        <?php if($errors->has('client_documents.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('client_documents.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <i class="<?php echo e(($index == 0 ? 'fa fa-plus' : 'fa fa-trash')); ?>" id="<?php echo e(($index == 0 ? 'plus-cd' : 'minus-cd')); ?>" style="cursor: pointer;"></i>
                                                    </td>
                                                    <input type="hidden" name="id_client_documents[]" value="<?php echo e($clientDocument['id']); ?>" />
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $clientDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="id_client_documents_old[<?php echo e($clientDocument['id']); ?>]" value="<?php echo e($clientDocument['id']); ?>" />
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="cloned-cd"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-tc">
                        <?php
                            $clientTermsAndConditions = $client->clientTermsAndConditions->toArray();

                            if (empty($clientTermsAndConditions)) {
                                $clientTermsAndConditions[] = [
                                    'id'                   => '',
                                    'terms_and_conditions' => ''
                                ];
                            }
                        ?>

                        <div class="col-md-2"><?php echo e(__('Terms and Condition')); ?></div>

                        <div class="col-md-10">
                            <table class="table table-respopnsive table-bordered" style="margin-bottom: 0;">
                                <thead>
                                    <tr>
                                        <th width="10%"><?php echo e(__('Default')); ?></th>
                                        <td><i class="text text-danger"><?php echo e(__('Default Terms and Condition')); ?></i></td>
                                    </tr>
                                </thead>
                            </table>
                            <?php $__currentLoopData = $clientTermsAndConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientTermsAndCondition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row" id="<?php echo e(($index == 0 ? 'main-tc' : '')); ?>">
                                    <div class="col-md-12">
                                        <table class="table table-respopnsive table-bordered" style="margin-bottom: 0;">
                                            <thead>
                                                <th width="1%">#</th>
                                                <th width="99%"><?php echo e(__('Custom')); ?></th>
                                                <th></th>
                                            </thead>

                                            <tbody>
                                                <tr>
                                                    <td ><?php echo e($index + 1); ?></td>
                                                    <td>
                                                        <textarea class="form-control<?php echo e($errors->has('terms_and_conditions.' . $index) ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="terms_and_conditions[]"><?php echo e(old('terms_and_conditions.' . $index, $clientTermsAndCondition['terms_and_conditions'])); ?></textarea>

                                                        <?php if($errors->has('terms_and_conditions.' . $index)): ?>
                                                            <span class="invalid-feedback" role="alert">
                                                                <strong><?php echo e($errors->first('terms_and_conditions.' . $index)); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <i class="<?php echo e(($index == 0 ? 'fa fa-plus' : '')); ?>" id="<?php echo e(($index == 0 ? 'plus-tc' : 'minus-tc')); ?>" style="cursor: pointer;"></i>
                                                    </td>
                                                    <input type="hidden" name="id_client_terms_and_conditions[]" value="<?php echo e($clientTermsAndCondition['id']); ?>" />
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div id="cloned-tc"></div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Nationality')); ?></div>
                        <div class="col-md-3">
                            <input id="nationality" type="text" class="form-control<?php echo e($errors->has('nationality') ? ' is-invalid' : ''); ?>" name="nationality" value="<?php echo e($client->nationality); ?>">

                            <?php if($errors->has('nationality')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('nationality')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Role')); ?></div>
                        <div class="col-md-3">
                            <?php if($client->isSuperAdmin()): ?>
                                <span class="badge badge-lg badge-secondary text-white">admin</span>
                            <?php else: ?>
                                <select class="form-control" name="role_id">
                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($role->id); ?>" <?php if($client->hasRole($role)): ?> selected <?php endif; ?>><?php echo e($role->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Work Status')); ?></div>
                        <div class="col-md-6">
                            <?php $__currentLoopData = $client::$workStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label>
                                    <input type="radio" id="status-<?php echo e(strtolower(str_ireplace(' ', '-', $text))); ?>" name="work_status" value="<?php echo e($value); ?>" <?php if($client->work_status == $text): ?> checked="true"' <?php endif; ?> />&nbsp;<?php echo e($text); ?>

                                </label>&nbsp;
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($errors->has('work_status')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('work_status')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="div-to-follow <?php echo e(($client->work_status == 'To Follow' ? '' : 'd-none')); ?>">
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Assign Date')); ?><span style="color: red;">*</span></div>
                            <div class="col-md-3">
                                <input id="assign_date" type="date" class="form-control<?php echo e($errors->has('assign_date') ? ' is-invalid' : ''); ?>" name="assign_date" value="<?php echo e((!empty($client->assign_date) ? date('Y-m-d', strtotime($client->assign_date)) : NULL)); ?>">

                                <?php if($errors->has('assign_date')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('assign_date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Assign To')); ?><span style="color: red;">*</span></div>
                            <div class="col-md-3">
                                <select id="assign_to"class="form-control<?php echo e($errors->has('assign_to') ? ' is-invalid' : ''); ?>" name="assign_to" >
                                    <option value=""><?php echo e(__('Select')); ?></option>

                                    <?php $__currentLoopData = $assignTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($assign->id); ?>" <?php echo e(($client->getAttributes()['assign_to'] == $assign->id ? 'selected' : '')); ?>><?php echo e($assign->first_name . ' ' . $assign->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if($errors->has('assign_to')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('assign_to')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Save')); ?>

                            </button>
                            <a href="<?php echo e(route('clients.show', $client->id)); ?>" class="btn btn-danger">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php echo $__env->make('app.clients.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/edit.blade.php ENDPATH**/ ?>