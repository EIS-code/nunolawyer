<?php $__env->startSection('sub_content'); ?>
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-car icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>
                    <?php echo e(__('Analytics Dashboard')); ?>

                    <div class="page-title-subheading">
                        <?php echo e(__('This is an analytical dashboard.')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-xl-4">
            <div class="card mb-3 widget-content bg-midnight-bloom">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading"><?php echo e(__('Total Clients')); ?></div>
                        <!--div class="widget-subheading"></div-->
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-white"><span><?php echo e(__('1896')); ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-4">
            <div class="card mb-3 widget-content bg-arielle-smile">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading"><?php echo e(__('Profits')); ?></div>
                        <div class="widget-subheading"><?php echo e(__('Total Clients Profit')); ?></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-white"><span><?php echo e(__('$ 568')); ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-4">
            <div class="card mb-3 widget-content bg-grow-early">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading"><?php echo e(__('Followers')); ?></div>
                        <div class="widget-subheading"><?php echo e(__('People Interested')); ?></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-white"><span><?php echo e(__('46%')); ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="d-xl-none d-lg-block col-md-6 col-xl-4">
            <div class="card mb-3 widget-content bg-premium-dark">
                <div class="widget-content-wrapper text-white">
                    <div class="widget-content-left">
                        <div class="widget-heading"><?php echo e(__('Products Sold')); ?></div>
                        <div class="widget-subheading"><?php echo e(__('Revenue streams')); ?></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-warning"><span><?php echo e(__('$14M')); ?></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/dashboard.blade.php ENDPATH**/ ?>