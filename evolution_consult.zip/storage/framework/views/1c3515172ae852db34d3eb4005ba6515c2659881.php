<?php $__env->startSection('sub_content'); ?>
	
    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="breadcrumb-item"><?php echo e(__('Permissions')); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(__('Add New Permission')); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="card bg-white">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('permissions.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Name')); ?></div>
                        <div class="col-md-8">
                            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Display Name')); ?></div>
                        <div class="col-md-8">
                            <input id="display_name" type="text" class="form-control<?php echo e($errors->has('display_name') ? ' is-invalid' : ''); ?>" name="display_name" value="<?php echo e(old('display_name')); ?>">

                            <?php if($errors->has('display_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('display_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Group Name')); ?></div>
                        <div class="col-md-8">
                           <input id="group_name" type="text" class="form-control<?php echo e($errors->has('group_name') ? ' is-invalid' : ''); ?>" name="group_name" value="<?php echo e(old('group_name')); ?>">

                            <?php if($errors->has('group_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('group_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                  
                    <div class="form-group row mb-0">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary">
                                <i class="metismenu-icon pe-7s-diskette"></i> <?php echo e(__('Create')); ?>

                            </button>
                            <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-danger">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/permissions/create.blade.php ENDPATH**/ ?>