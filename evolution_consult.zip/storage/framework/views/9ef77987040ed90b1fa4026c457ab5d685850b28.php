<?php $__env->startSection('sub_content'); ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('roles.index')); ?>" class="breadcrumb-item"><?php echo e(__('Roles')); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(__('Edit Role')); ?></span>
                    <span class="breadcrumb-item active"><?php echo e($role->name); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="card bg-white">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('roles.update', $role->id)); ?>">
                    <?php echo method_field('PATCH'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Name')); ?></div>
                        <div class="col-md-8">
                            <?php if($role->id === 1): ?>
                                <span class="badge badge-lg badge-secondary text-white">admin</span>
                            <?php else: ?>
                                <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>" name="name" value="<?php echo e($role->name); ?>"  autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Permissions')); ?></div>
                        <div class="col-md-8">
                            <table class="table table-striped table-bordered permissions_table">
                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <h6 class="mb-2 font-weight-bold"><label><?php echo e($group['name']); ?> <input type="checkbox" class="checkall"> </label></h6>

                                            <div>
                                                <?php $__currentLoopData = $group['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <label class="mr-4">
                                                        <input type="checkbox" name="<?php echo e($perm['name']); ?>" <?php if($role->hasPermissionTo($perm['id'])): ?> checked <?php endif; ?>>
                                                        <?php echo e($perm['display_name'] !== null ? $perm['display_name'] : $perm['name']); ?>

                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Save')); ?>

                            </button>
                            <a href="<?php echo e(route('roles.show', $role->id)); ?>" class="btn btn-danger">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/roles/edit.blade.php ENDPATH**/ ?>