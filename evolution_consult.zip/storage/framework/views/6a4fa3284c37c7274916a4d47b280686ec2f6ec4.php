<?php
    $isEditors = $client::$isEditors;
?>

<ul class="nav nav-tabs mb-4">
    <li class="nav-item">
        <a class="nav-link <?php if(Route::getCurrentRoute()->getName() == 'clients.show' || Route::getCurrentRoute()->getName() == 'editors.show'): ?> active <?php endif; ?>" href="<?php echo e(route(($isEditors ? 'editors.show' : 'clients.show'), $client->id)); ?>"><?php echo e(($isEditors ? __('Editor Details') : __('Client Details'))); ?></a>
    </li>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_activity')): ?>
        <li class="nav-item">
            <a class="nav-link <?php if(Route::getCurrentRoute()->getName() == 'clients.activity' || Route::getCurrentRoute()->getName() == 'editors.activity'): ?> active <?php endif; ?>" href="<?php echo e(route(($isEditors ? 'editors.activity' : 'clients.activity'), $client->id)); ?>"><?php echo e(__('Activity Log')); ?></a>
        </li>
    <?php endif; ?>
    <div style="margin-left: 30%;width: 67%;position: absolute;" class="page-title text-right">
        <div class="heading">
            <?php if(!$client->isSuperAdmin()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_edit')): ?>
                    <a href="<?php echo e(route(($isEditors ? 'editors.edit' : 'clients.edit'), $client->id)); ?>" class="btn btn-primary btn-round"><i class="fa fa-edit"></i> <span class="d-md-inline d-none"><?php echo e(__('Edit')); ?></span></a>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(!$client->isSuperAdmin()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_ban')): ?>
                    <?php if(!$client->banned): ?>
                        <!--a href="<?php echo e(route('clients.ban', $client->id)); ?>" class="btn btn-dark btn-round confirmBtn" data-confirm-message="<?php echo e(__('Are you sure you want to ban this client?')); ?>"><i class="fa fa-exclamation-triangle"></i> <span class="d-md-inline d-none"><?php echo e(__('Ban Clients')); ?></span></a-->
                    <?php endif; ?>
                <?php endif; ?>
            <?php endif; ?>

            <?php if(!$client->isSuperAdmin()): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_delete')): ?>
                    <form action="<?php echo e(route(($isEditors ? 'editors.destroy' : 'clients.destroy'), $client->id)); ?>" method="POST" class="d-inline">
                        <?php echo method_field('DELETE'); ?>
                        <?php echo csrf_field(); ?>
                        <button type="button" class="btn btn-danger btn-round deleteBtn" data-confirm-message="<?php echo e(__("Are you sure you want to delete this client?")); ?>"><i class="fa fa-trash"></i> <span class="d-md-inline d-none"><?php echo e(__('Delete')); ?></span></button>
                    </form>
                <?php endif; ?>
            <?php endif; ?>

            <a href="<?php echo e(route(($isEditors ? 'editors.index' : 'clients.index'))); ?>" class="btn btn-secondary btn-round"><i class="metismenu-icon pe-7s-back"></i> <span class="d-md-inline d-none"><?php echo e(__('Back To List')); ?></span></a>
        </div>
    </div>
</ul>
<?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/nav.blade.php ENDPATH**/ ?>