<?php $__env->startSection('sub_content'); ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('roles.index')); ?>" class="breadcrumb-item"><?php echo e(__('Roles')); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(__('Role Details')); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <div class="card bg-white">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="page-title pull-right">
                            <div class="heading">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_edit')): ?>
                                    <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-primary btn-round"><i class="fa fa-edit"></i> <span class="d-md-inline d-none"><?php echo e(__('Edit')); ?></span></a>
                                <?php endif; ?>

                                <?php if($role->id !== 1): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_delete')): ?>
                                        <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST" class="d-inline">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <button type="button" class="btn btn-danger btn-round deleteBtn" data-confirm-message="<?php echo e(__('Are you sure you want to delete this role?')); ?>"><i class="fa fa-trash"></i> <span class="d-md-inline d-none"><?php echo e(__('Delete')); ?></span></button>
                                        </form>
                                    <?php endif; ?>
                                <?php endif; ?>

                                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary btn-round"><i class="metismenu-icon pe-7s-back"></i> <span class="d-md-inline d-none"><?php echo e(__('Back To List')); ?></span></a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2"><?php echo e(__('Name')); ?></div>
                    <div class="col-md-8">
                        <?php echo e($role->name); ?>

                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-md-2"><?php echo e(__('Permissions')); ?></div>
                    <div class="col-md-8">
                        <table class="table table-striped table-bordered permissions_table">
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <h6 class="mb-2 font-weight-bold"><?php echo e($group['name']); ?></h6>
                                        <div>
                                            <?php $__currentLoopData = $group['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="mr-4">
                                                    <?php if($role->hasPermissionTo($perm['id'])): ?> 
                                                        <i class="metismenu-icon pe-7s-plus" style="color: green;"></i>
                                                    <?php else: ?>
                                                        <i class="metismenu-icon pe-7s-close-circle" style="color: red;"></i>
                                                    <?php endif; ?>
                                                    <?php echo e($perm['display_name'] !== null ? $perm['display_name'] : $perm['name']); ?>

                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/roles/show.blade.php ENDPATH**/ ?>