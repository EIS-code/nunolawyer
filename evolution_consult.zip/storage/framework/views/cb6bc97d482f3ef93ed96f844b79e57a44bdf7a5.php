<?php $__env->startSection('sub_content'); ?>

    <?php
        $isEditors = $client::$isEditors;
    ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('clients.index')); ?>" class="breadcrumb-item"><?php echo e(($isEditors ? __('Editors') : __('Clients'))); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(__('Activity Log')); ?></span>
                    <span class="breadcrumb-item active"><?php echo e($client->first_name . ' ' . $client->last_name); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="card bg-white">
            <div class="card-body">
                <?php echo $__env->make('app.clients.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                        <thead>
                            <tr>
                                <th width="1"></th>
                                <th width="1"></th>
                                <th><?php echo e(__('Date Time')); ?></th>
                                <th><?php echo e(__('Event')); ?></th>
                                <th><?php echo e(__('IP Address')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($audits->total() == 0): ?>
                                <tr>
                                    <td colspan="5"><?php echo e(__('No results found.')); ?></td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td width="1">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activitylog_show')): ?>
                                                <a href="<?php echo e(route('activitylog.show', $audit->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Activity Details')); ?>">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td width="1">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('activitylog_delete')): ?>
                                                <form action="<?php echo e(route('activitylog.destroy', $audit->id)); ?>" method="POST">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <a href="#" class="deleteBtn" data-confirm-message="<?php echo e(__("Are you sure you want to delete this activity?")); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Delete Activity')); ?>"><i class="fa fa-trash"></i></a>
                                                </form>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($audit->created_at); ?></td>
                                        <td><?php echo e(@$audit['event_message']); ?></td>
                                        <td><?php echo e($audit->ip_address); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <div class="float-left"><?php echo e($audits->links()); ?></div>

                    <div class="float-right text-muted">
                        <?php echo e(__('Showing')); ?> <?php echo e($audits->firstItem()); ?> - <?php echo e($audits->lastItem()); ?> / <?php echo e($audits->total()); ?> (<?php echo e(__('page')); ?> <?php echo e($audits->currentPage()); ?> )
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/activity.blade.php ENDPATH**/ ?>