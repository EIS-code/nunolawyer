<?php $__env->startSection('sub_content'); ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(__('Roles')); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card bg-white">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <form class="w-100">
                            <div class="input-group bg-light">
                                <input type="text" name="s" class="form-control searchInput" placeholder="<?php echo e(__('Search')); ?>" <?php if(!empty($term)): ?> value="<?php echo e($term); ?>" <?php endif; ?>>
                                <div class="input-group-append">
                                     <?php if(!empty($term)): ?>
                                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-light">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    <?php endif; ?>
                                    <button class="btn btn-primary">
                                        <i class="fa fa-search"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-8">
                        <div class="page-title pull-right">
                            <div class="heading">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_create')): ?>
                                    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-round float-right"><i class="metismenu-icon pe-7s-lock"></i> <?php echo e(__('Add New Role')); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card bg-white mt-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                        <thead>
                            <tr>
                                <th width="1"></th>
                                <th width="1"></th>
                                <th width="1"></th>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('Users')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($roles->total() == 0): ?>
                                <tr>
                                    <td colspan="5"><?php echo e(__('No results found.')); ?></td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td width="1">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_show')): ?>
                                                <a href="<?php echo e(route('roles.show', $role->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('View Role')); ?>">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td width="1">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_edit')): ?>
                                                <a href="<?php echo e(route('roles.edit', $role->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Edit Role')); ?>">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td width="1">
                                            <?php if($role->id !== 1): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles_delete')): ?>
                                                    <form action="<?php echo e(route('roles.destroy', $role->id)); ?>" method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <a href="#" class="deleteBtn" data-confirm-message="<?php echo e(__("Are you sure you want to delete this role?")); ?>"  data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Delete Role')); ?>">
                                                            <i class="fa fa-trash"></i>
                                                        </a>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(auth()->user()->can('roles_show')): ?>
                                                <a href="<?php echo e(route('roles.show', $role->id)); ?>"><?php echo e($role->name); ?></a>
                                            <?php else: ?>
                                                <?php echo e($role->name); ?>

                                            <?php endif; ?>
                                         </td>
                                         <td><?php echo e(count($role->users)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="float-left">
                        <?php if(!empty($term)): ?>
                            <?php echo e($roles->appends(['s' => $term])->links()); ?>

                        <?php else: ?>
                            <?php echo e($roles->links()); ?>

                        <?php endif; ?>
                    </div>

                    <div class="float-right text-muted">
                        <?php echo e(__('Showing')); ?> <?php echo e($roles->firstItem()); ?> - <?php echo e($roles->lastItem()); ?> / <?php echo e($roles->total()); ?> (<?php echo e(__('page')); ?> <?php echo e($roles->currentPage()); ?> )
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/roles/list.blade.php ENDPATH**/ ?>