<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo e(config('app.name', 'Nunolawyer')); ?></title>

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    </head>
    <body onbeforeprint="beforePrints()" onafterprint="afterPrints()">
        <div class="container">
            <div class="print-only" style="margin-top: 20px;width: 100%;font-size: 22px;">
                <h1 class="header" style="text-transform: uppercase;"><?php echo e($client->first_name .' '. $client->last_name); ?></h1>
                <table class="user-table table table-bordered">
                    <tbody>
                        <tr>
                            <td class="table-main"><?php echo e(__('Registered Date')); ?></td>
                            <td class="table-contain">
                                <?php echo e(date('Y-m-d', strtotime($client->registration_date))); ?>

                            </td>
                            <td class="table-main"><?php echo e(__('Terms and Condition')); ?></td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Name')); ?></td>
                            <td class="table-contain"><?php echo e($client->first_name .' '. $client->last_name); ?></td>
                            <td rowspan="8" style="width:50%;">
                                <p>1. <?php echo e(__('Adm. Fee is for mention purpose, Art and for one time attempt in Lisbon work area only, otherwise additional charge, hotel booking cost plus transportation charge 0.50 Cent Euro per K.M will be charged.')); ?></p>
                                <p>2. <?php echo e(__('Missing / Due amount will be charged before your appointment on any suitable day.')); ?></p>
                                <p>3. <?php echo e(__('All the money we have received and will be received is always non refundable.')); ?></p>
                                <p>4. <?php echo e(__('If the related authority, Gov. Policy, rules or law change in the mean time our fee is also subject to change without pre notice and information will be delivered at your presence in our office.')); ?></p>
                                <p>5.&nbsp; <?php echo e(__('It confirms the client is agreed to allow us to use their personal data and details for related work on their behalf.')); ?></p>
                                <p>6. <?php echo e(__('This document considers as an agreement between clients and us to follow their process, and also it is the receipt of payment. If client fails in agreement the purposed all amount will be charged accordingly by legal way.')); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Nationality')); ?></td>
                            <td class="table-contain"><?php echo e($client->nationality); ?></td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Date of Birth')); ?></td>
                            <td class="table-contain"><?php echo e($client->dob); ?></td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Email')); ?></td>
                            <td class="table-contain"><?php echo e($client->email); ?></td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Contact')); ?></td>
                            <td class="table-contain"><?php echo e($client->contact); ?></td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Process Address')); ?></td>
                            <td class="table-contain"><?php echo e($client->process_address); ?></td>
                        </tr>
                        <tr>
                            <td class="table-main"><?php echo e(__('Purpose/Art.')); ?></td>
                            <?php
                                $titles = [];
                                $client->clientPurposeArticles->map(function($data) use(&$titles) {
                                    $titles[] = $data->purposeArticle->title;
                                });
                            ?>
                            <td class="table-contain">
                                <?php echo e(implode(' / ', $titles)); ?>

                            </td>
                        </tr>
                    </tbody>
                </table>
                <table class="table table-bordered">
                    <thead>
                        <tr class="fee-header">
                            <th><?php echo e(__('Date')); ?></th>
                            <th><?php echo e(__('Fee Details')); ?></th>
                            <th><?php echo e(__('Lawyer Fee Euro')); ?></th>
                            <th><?php echo e(__('Fee Details')); ?></th>
                            <th><?php echo e(__('Gov. Or Fee Euro for other Authority')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $client->clientFees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientFee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td rowspan="3" style="text-align: center;vertical-align: middle;"><?php echo e(date('Y-m-d', strtotime($clientFee->date))); ?></td>
                                <td><?php echo e(__('Total Proposed')); ?></td>
                                <td><?php echo e($clientFee->proposed_lawyer_fee); ?></td>
                                <td><?php echo e(__('Total Proposed')); ?></td>
                                <td><?php echo e($clientFee->proposed_government_fee); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Received')); ?></td>
                                <td><?php echo e($clientFee->received_lawyer_fee); ?></td>
                                <td><?php echo e(__('Received')); ?></td>
                                <td><?php echo e($clientFee->received_government_fee); ?></td>
                            </tr>
                            <tr>
                                <td><?php echo e(__('Missing')); ?></td>
                                <td><?php echo e($clientFee->missing_lawyer_fee); ?></td>
                                <td><?php echo e(__('Missing')); ?></td>
                                <td><?php echo e($clientFee->missing_government_fee); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-bordered">
                    <thead>
                        <tr class="fee-header">
                            <th style="width:10%"><?php echo e(__('Date')); ?></th>
                            <th><?php echo e(__('Client Condition')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $client->clientConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientCondition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(date('Y-m-d', strtotime($clientCondition->date))); ?></td>
                                <td>
                                    <p><?php echo e($clientCondition->condition); ?></p>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-bordered" id="print-no">
                    <thead>
                        <tr class="fee-header">
                            <th style="width:10%"><?php echo e(__('Date')); ?></th>
                            <th>
                                <?php echo e(__('Client Private Information')); ?>

                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $client->clientPrivateInformations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientPrivateInformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(date('Y-m-d', strtotime($clientPrivateInformation->date))); ?></td>
                                <td>
                                    <p><?php echo e($clientPrivateInformation->private_information); ?></p>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <table class="table table-bordered">
                    <thead>
                        <tr class="fee-header">
                            <th style="width:10%"><?php echo e(__('Date')); ?></th>
                            <th><?php echo e(__('Progress Report To The Client')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $client->clientEmailProgressReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientEmailProgressReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(date('Y-m-d', strtotime($clientEmailProgressReport->date))); ?></td>
                                <td>
                                    <p><?php echo e($clientEmailProgressReport->progress_report); ?></p>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <br>
                -----------------<br>
                <?php echo e(__('Client Signature')); ?><br>
                <h1 class="nuno-header" style="padding-top:0px;">
                    <?php echo e(__('Dr. Nuno Ramos Correia')); ?><br>
                </h1>
                <p class="nuno-details">
                    <?php echo e(__('Lawyer Office Lisbon')); ?><br>
                    <?php echo e(__('Address: Avenida Almirante Reis n, 59, 3rd Floor to the right, 1150-011, Lisbon, Portugal.')); ?><br>
                    <?php echo e(__('Phone: +351211356129')); ?><br>
                    <?php echo e(__('Phone: +351966817351 (For Call/Message/Whats up /Viber /Imo)')); ?><br>
                    <?php echo e(__('Email: nrcadvogados.pt@gmail.com')); ?><br>
                </p>
            </div>
        </div>
    </body>
    <script type="text/javascript">
        function beforePrints()
        {
            let printNo = document.getElementById('print-no');

            if (printNo) {
                printNo.style.display = "none";
            }
        }

        function afterPrints()
        {
            let printNo = document.getElementById('print-no');

            if (printNo) {
                printNo.style.display = "block";
            }
        }
    </script>
</html>
<?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/print.blade.php ENDPATH**/ ?>