<?php $__env->startSection('sub_content'); ?>

    <?php
        $isEditors = $client::$isEditors;
    ?>
    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route('clients.index')); ?>" class="breadcrumb-item"><?php echo e(($isEditors ? __('Editors') : __('Clients'))); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(($isEditors ? __('Show Editor') : __('Show Client'))); ?></span>
                    <span class="breadcrumb-item active"><?php echo e($client->first_name . ' ' . $client->last_name); ?></span>
                </div>
            </div>
        </div>
    </div>
	
    <div class="content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <?php echo $__env->make('app.clients.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Registration Date')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->registration_date); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('First Name')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->first_name); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Last Name')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->last_name); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Email')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->email); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Secondary Email')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->secondary_email); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('DOB')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->dob); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Contact')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->contact); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Passport Number')); ?></div>
                            <div class="col-md-3">
                                <?php echo e($client->passport_number); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Process Address')); ?></div>
                            <div class="col-md-8">
                                <?php echo e($client->process_address); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Purpose and Article')); ?></div>
                            <div class="col-md-8">
                                <?php
                                    $titles = [];
                                    $client->clientPurposeArticles->map(function($data) use(&$titles) {
                                        $titles[] = $data->purposeArticle->title;
                                    });
                                ?>
                                <?php echo e(implode(", ", $titles)); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Client Condition / Work To Do')); ?></div>
                            <div class="col-md-8">
                                <table class="table table-respopnsive table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="1%">#</th>
                                            <th width="25%"><?php echo e(__('Date')); ?></th>
                                            <th width="74%"><?php echo e(__('Client Condition ')); ?></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $client->clientConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientCondition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($clientCondition->date); ?></td>
                                                <td><?php echo e($clientCondition->condition); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Client Fee')); ?></div>
                            <div class="col-md-10">
                                <table class="table table-respopnsive table-bordered">
                                    <thead>
                                        <tr>
                                            <th style="width: 1%">#</th>
                                            <th style="width: 10%"><?php echo e(__('Date')); ?></th>
                                            <th style="width: 15%"><?php echo e(__('Total Proposed - Lawyer Fee')); ?></th>
                                            <th style="width: 15%"><?php echo e(__('Received -Lawyer Fee')); ?></th>
                                            <th style="width: 15%"><?php echo e(__('Missing- Lawyer Fee')); ?></th>
                                            <th style="width: 15%"><?php echo e(__('Total Proposed-Gov Fee')); ?></th>
                                            <th style="width: 15%"><?php echo e(__('Received-Gov Fee')); ?></th>
                                            <th style="width: 15%"><?php echo e(__('Missing-Gov Fee')); ?></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $client->clientFees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientFee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($clientFee->date); ?></td>
                                                <td><?php echo e($clientFee->proposed_lawyer_fee); ?></td>
                                                <td><?php echo e($clientFee->received_lawyer_fee); ?></td>
                                                <td><?php echo e($clientFee->missing_lawyer_fee); ?></td>
                                                <td><?php echo e($clientFee->proposed_government_fee); ?></td>
                                                <td><?php echo e($clientFee->received_government_fee); ?></td>
                                                <td><?php echo e($clientFee->missing_government_fee); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Progress Report To The Client (By Email)')); ?></div>
                            <div class="col-md-8">
                                <table class="table table-respopnsive table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="1%">#</th>
                                            <th width="25%"><?php echo e(__('Date')); ?></th>
                                            <th width="64%"><?php echo e(__('Progress Report')); ?></th>
                                            <th width="10%"><?php echo e(__('File')); ?></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $client->clientEmailProgressReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientEmailProgressReport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($clientEmailProgressReport->date); ?></td>
                                                <td><?php echo e($clientEmailProgressReport->progress_report); ?></td>
                                                <td>
                                                    <a href="<?php echo e($clientEmailProgressReport->file); ?>" target="__blank">
                                                        <?php echo e(__('View')); ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Client Private Informations')); ?></div>
                            <div class="col-md-8">
                                <table class="table table-respopnsive table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="1%">#</th>
                                            <th width="25%"><?php echo e(__('Date')); ?></th>
                                            <th width="74%"><?php echo e(__('Client Private Informations')); ?></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $client->clientPrivateInformations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientPrivateInformation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td><?php echo e($clientPrivateInformation->date); ?></td>
                                                <td><?php echo e($clientPrivateInformation->private_information); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Client Documents')); ?></div>
                            <div class="col-md-8">
                                <table class="table table-respopnsive table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="1%">#</th>
                                            <th width="99%"><?php echo e(__('File')); ?></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $client->clientDocuments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientDocument): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td>
                                                    <a href="<?php echo e($clientDocument->file); ?>" target="__blank">
                                                        <?php echo e(__('View')); ?>

                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Terms and Condition')); ?></div>
                            <div class="col-md-8">
                                <table class="table table-respopnsive table-bordered">
                                    <thead>
                                        <tr>
                                            <th width="1%">#</th>
                                            <th width="99%"><?php echo e(__('Custom')); ?></th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        <?php $__currentLoopData = $client->clientTermsAndConditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $clientTermsAndCondition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($index + 1); ?></td>
                                                <td>
                                                    <?php echo e($clientTermsAndCondition->terms_and_conditions); ?>

                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Work Status')); ?></div>
                            <div class="col-md-3">
                                <?php echo e($client->work_status); ?>

                            </div>
                        </div>
                        <?php if($client->work_status == '1'): ?>
                            <div class="form-group row">
                                <div class="col-md-2"><?php echo e(__('Assign Date')); ?></div>
                                <div class="col-md-8">
                                    <?php echo e($client->assign_date); ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-2"><?php echo e(__('Assign To')); ?></div>
                                <div class="col-md-8">
                                    <?php echo e($client->assign_to); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Created at')); ?></div>
                            <div class="col-md-3">
                                <?php echo e($client->created_at); ?>

                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Role')); ?></div>
                            <div class="col-md-3">
                                <span class="badge badge-lg badge-secondary text-white"><?php echo e(@$client->getRoleNames()[0]); ?></span>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Permissions')); ?></div>
                            <div class="col-md-10">
                                <table class="table table-striped table-bordered permissions_table">
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <h6 class="mb-2 font-weight-bold"><?php echo e($group['name']); ?></h6>
                                                <div>
                                                    <?php $__currentLoopData = $group['permissions']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <label class="mr-4">
                                                            <?php if($client->hasPermissionTo($perm['id'])): ?> 
                                                                <i class="metismenu-icon pe-7s-plus" style="color: green;"></i>
                                                            <?php else: ?>
                                                                <i class="metismenu-icon pe-7s-close-circle" style="color: red;"></i>
                                                            <?php endif; ?>
                                                            <?php echo e($perm['display_name'] !== null ? $perm['display_name'] : $perm['name']); ?>

                                                        </label>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/show.blade.php ENDPATH**/ ?>