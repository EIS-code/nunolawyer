<?php $__env->startSection('sub_content'); ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <?php if($request->has('new')): ?>
                        <a href="<?php echo e(route('clients.index')); ?>" class="breadcrumb-item"><?php echo e(__('Clients')); ?></a>
                        <span class="breadcrumb-item"><?php echo e(__('New Clients')); ?></span>
                    <?php elseif($request->has('banned')): ?>
                        <a href="<?php echo e(route('clients.index')); ?>" class="breadcrumb-item"><?php echo e(__('Clients')); ?></a>
                        <span class="breadcrumb-item"><?php echo e(__('Banned Clients')); ?></span>
                    <?php else: ?>
                        <span class="breadcrumb-item active"><?php echo e(__('Clients')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <div class="card bg-white">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <form class="w-100">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label><?php echo e(__('Name, mobile or email')); ?></label>
                                        <input type="text" name="s" class="form-control searchInput" placeholder="<?php echo e(__('Search  by name, mobile or email')); ?>" <?php if(!empty($term->get('s'))): ?> value="<?php echo e($term->get('s')); ?>" <?php endif; ?>>
                                    </div>
                                    <div class="col-md-6">
                                         <label><?php echo e(__('DOB')); ?></label>
                                         <div class="input-group">
                                            <input type="date" name="dob" class="form-control" <?php if(!empty($term->get('dob'))): ?> value="<?php echo e($term->get('dob')); ?>" <?php endif; ?>>
                                        </div>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-6">
                                        <label><?php echo e(__('Registered From / To')); ?></label>
                                        <div class="input-group">
                                            <!--label>
                                                <button type="button" class="btn btn-default">
                                                    <?php echo e(__('From')); ?>

                                                </button>   
                                            </label-->
                                            <input type="date" name="rs" class="form-control" <?php if(!empty($term->get('rs'))): ?> value="<?php echo e($term->get('rs')); ?>" <?php endif; ?>>
                                            <!--label>
                                                <button type="button" class="btn btn-default">
                                                    <?php echo e(__('To')); ?>

                                                </button>   
                                            </label-->
                                            <input type="date" name="rst" class="form-control" <?php if(!empty($term->get('rst'))): ?> value="<?php echo e($term->get('rst')); ?>" <?php endif; ?>>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <label><?php echo e(__('Purpose / Article')); ?></label>

                                        <select class="form-control" name="pur">
                                            <option value=""><?php echo e(__('Select')); ?></option>

                                            <?php
                                                $purposeArticles = $clientModel::getAllClientPurposeArticles();
                                            ?>

                                            <?php if(!empty($purposeArticles) && !$purposeArticles->isEmpty()): ?>
                                                <?php $__currentLoopData = $purposeArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purposeArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($purposeArticle['id']); ?>" <?php if($term->get('pur')): ?> selected="true" <?php endif; ?>><?php echo e($purposeArticle['title']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>
                                </div>
                                <br />
                                <div class="row">
                                    <div class="col-md-6">
                                        <label><?php echo e(__('Work Status')); ?></label>
                                    </div>
                                    <div class="col-md-12">
                                        <select name="ws[]" multiple="true">
                                            <option value=""><?php echo e(__('Select')); ?></option>

                                            <?php $__currentLoopData = $clientModel::$workStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>" <?php echo (!empty($term->get('ws')) && in_array($value, $term->get('ws')) ? 'selected' : ''); ?>><?php echo e($text); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <br />

                                <div class="input-group-append">
                                     <?php if($isFiltered == true): ?>
                                        <a href="<?php echo e(route('clients.index')); ?>" class="btn btn-light">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    <?php endif; ?>
                                    <button class="btn btn-primary">
                                        <i class="fa fa-search"></i>
                                    </button>
                                    <!--input type="hidden" name="export" id="export" value="" />
                                    <button class="btn btn-success" onclick="javascript: document.getElementById('export').value = 'export';">
                                        <i class="fa fa-file"></i>
                                        <?php echo e(__('Export')); ?>

                                    </button-->
                                    <button type="submit" name="export" value="<?php echo e(__('Export')); ?>" class="btn btn-success">
                                        <i class="fa fa-file"></i>
                                        <?php echo e(__('Export')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-md-4">
                        <div class="page-title pull-right">
                            <div class="heading">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_create')): ?>
                                    <a href="<?php echo e(route('clients.create')); ?>" class="btn btn-primary btn-round"><i class="metismenu-icon pe-7s-user"></i> <?php echo e(__('Add New Client')); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card bg-white mt-3">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped table-borderless">
                        <thead>
                            <tr>
                                <th width="1"></th>
                                <th width="1"></th>
                                <th width="1"></th>
                                <th><?php echo e(__('Registered Date')); ?></th>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('DOB')); ?></th>
                                <th><?php echo e(__('Nationality')); ?></th>
                                <th><?php echo e(__('Passport/Art.')); ?></th>
                                <th><?php echo e(__('E-mail')); ?></th>
                                <th><?php echo e(__('Contact')); ?></th>
                                <th><?php echo e(__('Role')); ?></th>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_activity')): ?>
                                    <th><?php echo e(__('Log')); ?></th>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_print')): ?>
                                    <th><?php echo e(__('View')); ?></th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($clients->total() == 0): ?>
                                <tr>
                                    <td colspan="12" class="text-center"><mark><?php echo e(__('No results found.')); ?></mark></td>
                                </tr>
                            <?php else: ?>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td width="1">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_show')): ?>
                                                <a href="<?php echo e(route('clients.show', $client->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('View Client')); ?>">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                        <td width="1">
                                            <?php if(!$client->isSuperAdmin()): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_edit')): ?>
                                                    <a href="<?php echo e(route('clients.edit', $client->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Edit Client')); ?>">
                                                        <i class="fa fa-edit"></i>
                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                        <td width="1">
                                            <?php if(!$client->isSuperAdmin()): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_delete')): ?>
                                                    <form action="<?php echo e(route('clients.destroy', $client->id)); ?>" method="POST">
                                                        <?php echo method_field('DELETE'); ?>
                                                        <?php echo csrf_field(); ?>
                                                        <a href="#" class="deleteBtn" data-confirm-message="<?php echo e(__("Are you sure you want to delete this client?")); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__('Delete Client')); ?>"><i class="fa fa-trash"></i></a>
                                                    </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($client->registration_date); ?></td>
                                        <td>
                                            <?php if(auth()->user()->can('clients_show')): ?>
                                                <a href="<?php echo e(route('clients.show', $client->id)); ?>"><?php echo e($client->first_name . ' ' . $client->last_name); ?></a>
                                            <?php else: ?>
                                                <?php echo e($client->first_name . ' ' . $client->last_name); ?>

                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($client->dob); ?></td>
                                        <td><?php echo e($client->nationality); ?></td>
                                        <td><?php echo e($client->passport_number . ' / ' . $client->process_address); ?></td>
                                        <td><?php echo e($client->email); ?></td>
                                        <td><?php echo e($client->contact); ?></td>
                                        <td><span class="badge badge-lg badge-secondary text-white"><?php echo e(@$client->getRoleNames()[0]); ?></span></td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_activity')): ?>
                                            <td>
                                                <a href="<?php echo e(route('clients.activity', $client->id)); ?>#" target="_blank"><?php echo e(__('Log')); ?></a>
                                            </td>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('clients_print')): ?>
                                            <td>
                                                <a href="<?php echo e(route('clients.print', $client->id)); ?>" target="_blank"><?php echo e(__('Print')); ?></a>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>

                    <div class="float-left">
                        <?php if(!empty($term)): ?>
                            <?php echo e($clients->appends(['s' => $term])->links()); ?>

                        <?php else: ?>
                            <?php echo e($clients->links()); ?>

                        <?php endif; ?>
                    </div>

                    <div class="float-right text-muted">
                        <?php echo e(__('Showing')); ?> <?php echo e($clients->firstItem()); ?> - <?php echo e($clients->lastItem()); ?> / <?php echo e($clients->total()); ?> (<?php echo e(__('page')); ?> <?php echo e($clients->currentPage()); ?> )
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/list.blade.php ENDPATH**/ ?>