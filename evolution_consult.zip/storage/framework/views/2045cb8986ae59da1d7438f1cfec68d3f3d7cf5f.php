<?php $__env->startSection('sub_content'); ?>

    <?php
        $isEditors = $clientModel::$isEditors;
    ?>

    <div class="page-header">
        <div class="breadcrumb-line">
            <div class="d-flex">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('dashboard')); ?>" class="breadcrumb-item"><i class="metismenu-icon pe-7s-home" style="margin-top: 3px;"></i>&nbsp;<?php echo e(__('Dashboard')); ?></a>
                    <a href="<?php echo e(route(($isEditors ? 'editors.index' : 'clients.index'))); ?>" class="breadcrumb-item"><?php echo e(($isEditors ? __('Editors') : __('Clients'))); ?></a>
                    <span class="breadcrumb-item active"><?php echo e(($isEditors ? __('Add New Editor') : __('Add New Client'))); ?></span>
                </div>
            </div>
        </div>
    </div>

    <div class="content">
        <div class="card bg-white">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('clients.store')); ?>" enctype='multipart/form-data'>
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Registration Date')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="registration_date" type="date" class="form-control<?php echo e($errors->has('registration_date') ? ' is-invalid' : ''); ?>" name="registration_date" value="<?php echo e(old('registration_date', date('Y-m-d', time()))); ?>" required autofocus>

                            <?php if($errors->has('registration_date')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('registration_date')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('First Name') . ' ' . __('(Middle Name if any)')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="first_name" type="text" class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>" name="first_name" value="<?php echo e(old('first_name')); ?>">

                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Last Name')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="last_name" type="text" class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>" name="last_name" value="<?php echo e(old('last_name')); ?>">

                            <?php if($errors->has('last_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('last_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('E-Mail')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Secondary E-Mail')); ?></div>
                        <div class="col-md-8">
                            <input id="secondary_email" type="email" class="form-control<?php echo e($errors->has('secondary_email') ? ' is-invalid' : ''); ?>" name="secondary_email" value="<?php echo e(old('secondary_email')); ?>">

                            <?php if($errors->has('secondary_email')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('secondary_email')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Password')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Confirm Password')); ?><span style="color: red;">*</span></div>
                        <div class="col-md-8">
                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Date of birth')); ?></div>
                        <div class="col-md-8">
                            <input id="dob" type="date" class="form-control<?php echo e($errors->has('dob') ? ' is-invalid' : ''); ?>" name="dob" value="<?php echo e(old('dob')); ?>">

                            <?php if($errors->has('dob')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('dob')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Contact')); ?></div>
                        <div class="col-md-3">
                            <input id="contact" type="number" class="form-control<?php echo e($errors->has('contact') ? ' is-invalid' : ''); ?>" name="contact" value="<?php echo e(old('contact')); ?>">

                            <?php if($errors->has('contact')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('contact')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Passport Number')); ?></div>
                        <div class="col-md-3">
                            <input id="passport_number" type="text" class="form-control<?php echo e($errors->has('passport_number') ? ' is-invalid' : ''); ?>" name="passport_number" value="<?php echo e(old('passport_number')); ?>">

                            <?php if($errors->has('passport_number')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('passport_number')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Process Address')); ?></div>
                        <div class="col-md-8">
                            <input id="process_address" type="text" class="form-control<?php echo e($errors->has('process_address') ? ' is-invalid' : ''); ?>" name="process_address" value="<?php echo e(old('process_address')); ?>">

                            <?php if($errors->has('process_address')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('process_address')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Nationality')); ?></div>
                        <div class="col-md-3">
                            <input id="nationality" type="text" class="form-control<?php echo e($errors->has('nationality') ? ' is-invalid' : ''); ?>" name="nationality" value="<?php echo e(old('nationality')); ?>">

                            <?php if($errors->has('nationality')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('nationality')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Purpose and Article')); ?></div>
                        <div class="col-md-8">
                            <select class="form-control<?php echo e($errors->has('nationality') ? ' is-invalid' : ''); ?>" name="purpose_articles[]" multiple="true">
                                <option value="" <?php echo e((empty(old('purpose_articles')) ? 'selected="true"' : '')); ?>><?php echo e(__('Select')); ?></option>

                                <?php $__currentLoopData = $purposeArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purposeArticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($purposeArticle->id); ?>" <?php echo e((!empty(old('purpose_articles')) && in_array($purposeArticle->id, old('purpose_articles')) ? 'selected="true"' : '')); ?>><?php echo e($purposeArticle->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('purpose_articles')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('purpose_articles')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row" id="row-pa">
                        <div class="col-md-2"><?php echo e(__('Client Condition / Work To Do')); ?></div>

                        <div class="col-md-10">
                            <div class="row" id="main-pa">
                                <div class="col-md-12">
                                    <table class="table table-respopnsive table-bordered">
                                        <thead>
                                            <th width="1%">#</th>
                                            <th width="20%"><?php echo e(__('Date')); ?></th>
                                            <th width="79%"><?php echo e(__('Client Condition')); ?></th>
                                            <th></th>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td >1</td>
                                                <td>
                                                    <input type="date" class="form-control<?php echo e($errors->has('condition_dates.0') ? ' is-invalid' : ''); ?>" name="condition_dates[]" value="<?php echo e(old('condition_dates.0')); ?>">

                                                    <?php if($errors->has('condition_dates.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('condition_dates.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <textarea class="form-control<?php echo e($errors->has('conditions.0') ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="conditions[]"><?php echo e(old('conditions.0')); ?></textarea>

                                                    <?php if($errors->has('conditions.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('conditions.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <i class="fa fa-plus" id="plus-pa" style="cursor: pointer;"></i>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div id="cloned-pa"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-cf">
                        <div class="col-md-2"><?php echo e(__('Client Fee')); ?></div>

                        <div class="col-md-10">
                            <div class="row" id="main-cf">
                                <div class="col-md-12 table-respopnsive text-nowrap">
                                    <table class="table table-bordered" width="100%;">
                                        <thead>
                                            <tr>
                                                <th style="width: 1%">#</th>
                                                <th style="width: 10%"><?php echo e(__('Date')); ?></th>
                                                <th style="width: 15%"><?php echo e(__('Total Proposed - Lawyer Fee')); ?></th>
                                                <th style="width: 15%"><?php echo e(__('Received -Lawyer Fee')); ?></th>
                                                <th style="width: 15%"><?php echo e(__('Missing- Lawyer Fee')); ?></th>
                                                <th style="width: 1%"></th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td rowspan="4">1</td>
                                                <td>
                                                    <input type="date" class="form-control<?php echo e($errors->has('fee_dates.0') ? ' is-invalid' : ''); ?>" name="fee_dates[]" value="<?php echo e(old('fee_dates.0')); ?>">

                                                    <?php if($errors->has('fee_dates.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('fee_dates.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="text" class="form-control<?php echo e($errors->has('total_proposed_lawyer_fee.0') ? ' is-invalid' : ''); ?>" name="total_proposed_lawyer_fee[]" value="<?php echo e(old('total_proposed_lawyer_fee.0')); ?>">

                                                    <?php if($errors->has('total_proposed_lawyer_fee.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('total_proposed_lawyer_fee.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control<?php echo e($errors->has('received_lawyer_fee.0') ? ' is-invalid' : ''); ?>" name="received_lawyer_fee[]" value="<?php echo e(old('received_lawyer_fee.0')); ?>">

                                                    <?php if($errors->has('received_lawyer_fee.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('received_lawyer_fee.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control<?php echo e($errors->has('missing_lawyer_fee.0') ? ' is-invalid' : ''); ?>" name="missing_lawyer_fee[]" value="<?php echo e(old('missing_lawyer_fee.0')); ?>">

                                                    <?php if($errors->has('missing_lawyer_fee.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('missing_lawyer_fee.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td  rowspan="4">
                                                    <i class="fa fa-plus" id="plus-cf" style="cursor: pointer;"></i>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th style="width: 15%"><?php echo e(__('Total Proposed-Gov Fee')); ?></th>
                                                <th style="width: 15%"><?php echo e(__('Received-Gov Fee')); ?></th>
                                                <th style="width: 15%"><?php echo e(__('Missing-Gov Fee')); ?></th>
                                                <th rowspan="2"></th>
                                            <tr>
                                                <td>
                                                    <input type="text" class="form-control<?php echo e($errors->has('total_proposed_government_fee.0') ? ' is-invalid' : ''); ?>" name="total_proposed_government_fee[]" value="<?php echo e(old('total_proposed_government_fee.0')); ?>">

                                                    <?php if($errors->has('total_proposed_government_fee.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('total_proposed_government_fee.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control<?php echo e($errors->has('received_government_fee.0') ? ' is-invalid' : ''); ?>" name="received_government_fee[]" value="<?php echo e(old('received_government_fee.0')); ?>">

                                                    <?php if($errors->has('received_government_fee.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('received_government_fee.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="number" class="form-control<?php echo e($errors->has('missing_government_fee.0') ? ' is-invalid' : ''); ?>" name="missing_government_fee[]" value="<?php echo e(old('missing_government_fee.0')); ?>">

                                                    <?php if($errors->has('missing_government_fee.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('missing_government_fee.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div id="cloned-cf"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-pr">
                        <div class="col-md-2"><?php echo e(__('Progress Report To The Client (By Email)')); ?></div>

                        <div class="col-md-10">
                            <div class="row" id="main-pr">
                                <div class="table-respopnsive col-md-12">
                                    <table class="table table-bordered">
                                        <thead>
                                            <th width="1%">#</th>
                                            <th width="20%"><?php echo e(__('Date')); ?></th>
                                            <th width="69%"><?php echo e(__('Progress Report')); ?></th>
                                            <th width="10%"><?php echo e(__('File')); ?></th>
                                            <th></th>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td >1</td>
                                                <td>
                                                    <input type="date" class="form-control<?php echo e($errors->has('progress_report_dates.0') ? ' is-invalid' : ''); ?>" name="progress_report_dates[]" value="<?php echo e(old('progress_report_dates.0')); ?>">

                                                    <?php if($errors->has('progress_report_dates.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('progress_report_dates.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <textarea class="form-control<?php echo e($errors->has('progress_reports.0') ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="progress_reports[]"><?php echo e(old('progress_reports.0')); ?></textarea>

                                                    <?php if($errors->has('progress_reports.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('progress_reports.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <input type="file" class="<?php echo e($errors->has('progress_report_files.0') ? ' is-invalid' : ''); ?>" name="progress_report_files[]" />

                                                    <?php if($errors->has('progress_report_files.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('progress_report_files.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <i class="fa fa-plus" id="plus-pr" style="cursor: pointer;"></i>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div id="cloned-pr"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-ci">
                        <div class="col-md-2"><?php echo e(__('Client Private Information')); ?></div>

                        <div class="col-md-10">
                            <div class="row" id="main-ci">
                                <div class="col-md-12">
                                    <table class="table table-respopnsive table-bordered">
                                        <thead>
                                            <th width="1%">#</th>
                                            <th width="20%"><?php echo e(__('Date')); ?></th>
                                            <th width="79%"><?php echo e(__('Client Private Information')); ?></th>
                                            <th></th>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td >1</td>
                                                <td>
                                                    <input type="date" class="form-control<?php echo e($errors->has('client_private_dates.0') ? ' is-invalid' : ''); ?>" name="client_private_dates[]" value="<?php echo e(old('client_private_dates.0')); ?>">

                                                    <?php if($errors->has('client_private_dates.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('client_private_dates.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <textarea class="form-control<?php echo e($errors->has('client_private_informations.0') ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="client_private_informations[]"><?php echo e(old('client_private_informations.0')); ?></textarea>

                                                    <?php if($errors->has('client_private_informations.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('client_private_informations.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <i class="fa fa-plus" id="plus-ci" style="cursor: pointer;"></i>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div id="cloned-ci"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-cd">
                        <div class="col-md-2"><?php echo e(__('Client Documents')); ?></div>

                        <div class="col-md-10">
                            <div class="row" id="main-cd">
                                <div class="col-md-12">
                                    <table class="table table-respopnsive table-bordered">
                                        <thead>
                                            <th width="1%">#</th>
                                            <th width="99%"><?php echo e(__('File')); ?></th>
                                            <th></th>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td >1</td>
                                                <td>
                                                    <input type="file" class="form-control<?php echo e($errors->has('client_documents.0') ? ' is-invalid' : ''); ?>" name="client_documents[]" value="<?php echo e(old('client_documents.0')); ?>">

                                                    <?php if($errors->has('client_documents.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('client_documents.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <i class="fa fa-plus" id="plus-cd" style="cursor: pointer;"></i>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div id="cloned-cd"></div>

                        </div>
                    </div>

                    <div class="form-group row" id="row-tc">
                        <div class="col-md-2"><?php echo e(__('Terms and Condition')); ?></div>

                        <div class="col-md-10">
                            <table class="table table-respopnsive table-bordered" style="margin-bottom: 0;">
                                <thead>
                                    <tr>
                                        <th width="10%"><?php echo e(__('Default')); ?></th>
                                        <td><i class="text text-danger"><?php echo e(__('Default Terms and Condition')); ?></i></td>
                                    </tr>
                                </thead>
                            </table>
                            <div class="row" id="main-tc">
                                <div class="col-md-12">
                                    <table class="table table-respopnsive table-bordered" style="margin-bottom: 0;">
                                        <thead>
                                            <th width="1%">#</th>
                                            <th width="99%"><?php echo e(__('Custom')); ?></th>
                                            <th></th>
                                        </thead>

                                        <tbody>
                                            <tr>
                                                <td >1</td>
                                                <td>
                                                    <textarea class="form-control<?php echo e($errors->has('terms_and_conditions.0') ? ' is-invalid' : ''); ?>" rows="2" cols="5" name="terms_and_conditions[]"><?php echo e(old('terms_and_conditions.0')); ?></textarea>

                                                    <?php if($errors->has('terms_and_conditions.0')): ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($errors->first('terms_and_conditions.0')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <i class="fa fa-plus" id="plus-tc" style="cursor: pointer;"></i>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <div id="cloned-tc"></div>

                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Role')); ?></div>
                        <div class="col-md-3">
                            <select class="form-control" name="role_id">
                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($role->id); ?>" <?php echo e(($isEditors && $role->id == '3' ? 'selected="true"' : 'disabled="true"')); ?>><?php echo e($role->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2"><?php echo e(__('Work Status')); ?></div>
                        <div class="col-md-6">
                            <!--label><input type="radio" id="status-default" name="work_status" value="0" <?php if(old('work_status') == '0' || old('work_status') == ''): ?> checked="true" <?php endif; ?> />&nbsp;<?php echo e(__('Default')); ?></label>
                            <label><input type="radio" id="status-to-follow" name="work_status" value="1" <?php if(old('work_status') == '1'): ?> checked="true" <?php endif; ?> />&nbsp;<?php echo e(__('To Follow')); ?></label-->
                            <?php $__currentLoopData = $clientModel::$workStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($value == '2'): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                <label>
                                    <input type="radio" id="status-<?php echo e(strtolower(str_ireplace(' ', '-', $text))); ?>" name="work_status" value="<?php echo e($value); ?>" <?php if(old('work_status') == $value): ?> checked="true"' <?php endif; ?> />&nbsp;<?php echo e($text); ?>

                                </label>&nbsp;
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php if($errors->has('work_status')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('work_status')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="div-to-follow <?php echo e((old('work_status') == '1' ? '' : 'd-none')); ?>">
                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Assign Date')); ?><span style="color: red;">*</span></div>
                            <div class="col-md-3">
                                <input id="assign_date" type="date" class="form-control<?php echo e($errors->has('assign_date') ? ' is-invalid' : ''); ?>" name="assign_date" value="<?php echo e(old('assign_date')); ?>">

                                <?php if($errors->has('assign_date')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('assign_date')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-2"><?php echo e(__('Assign To')); ?><span style="color: red;">*</span></div>
                            <div class="col-md-3">
                                <select id="assign_to"class="form-control<?php echo e($errors->has('assign_to') ? ' is-invalid' : ''); ?>" name="assign_to" >
                                    <option value=""><?php echo e(__('Select')); ?></option>

                                    <?php $__currentLoopData = $assignTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($assign->id); ?>" <?php echo e((old('assign_to') == $assign->id ? 'selected' : '')); ?>><?php echo e($assign->first_name . ' ' . $assign->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <?php if($errors->has('assign_to')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('assign_to')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group row mb-0">
                        <div class="col-md-2"></div>
                        <div class="col-md-8">
                            <button type="submit" class="btn btn-primary">
                                <i class="metismenu-icon pe-7s-diskette"></i> <?php echo e(__('Create')); ?>

                            </button>
                            <a href="<?php echo e(route(($isEditors ? 'editors.index' : 'clients.index'))); ?>" class="btn btn-danger">
                                <?php echo e(__('Cancel')); ?>

                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php echo $__env->make('app.clients.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Jaydeep Mor\Work\Evolution IT Solutions\Consult Evolution\evolution_consult\resources\views/app/clients/create.blade.php ENDPATH**/ ?>